const mongoose = require('mongoose');
const Schema = mongoose.Schema;

const OrgSchema = new Schema({
    name:{
        type: String,
        required : true
    },
    email:{
        type : String,
        required : true
    },
    orgtype:{
        type : String,
        required : true
    } ,
    
    orgimage:{
        type:String,
        required : true
    },
    password:{
        type: String,
        required : true
    },
    estyear:{
        type: Number,
        required : true
    },
    GSTIN:{
        type: String,
        required : true
    },
    PAN:{
        type: String,
        required : true
    },
    MOA:{
        type: String,
        required : true
    }
})

module.exports = Org = mongoose.model('org',OrgSchema);