const mongoose = require('mongoose');
const Schema = mongoose.Schema;

const FriendRequestSchema = new Schema({
 

    userid:{
        type:String
    },

    requestList:[{
        userid : {
                type :String
            }
    }],
    
    requestedList:[{
        userid : {
                type :String
            }
    }],


    friendList :[{
        userid : {
                type :String
            }
    }]
})


module.exports = Profile = mongoose.model('userFriendRequest', FriendRequestSchema)