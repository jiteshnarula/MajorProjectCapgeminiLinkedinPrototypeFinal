const mongoose = require('mongoose');
const Schema = mongoose.Schema;

const PostSchema = new Schema({
    userRegData:{
        type: Schema.Types.ObjectId,
        ref: 'users'
    },
    userid:{
        type:String 
    },
    message:{
        type:String,
        required : true
    },
    name:{
        type:String
    },
    userimage:{
        type:String
    },
    likes:[
        {
            userid :{
                type:String 
            }

        }
    ],
    comments:[
        {
            userid:{
                type: String 
            },
            message:{
                type:String,
                required: true
            },
            name:{
                type:String
            },
           
            date:{
                type:Date,
                default: Date.now
            }

        }
    ],
    
    date:{
        type:Date,
        default: Date.now
    }


})


module.exports = Post = mongoose.model("post",PostSchema)