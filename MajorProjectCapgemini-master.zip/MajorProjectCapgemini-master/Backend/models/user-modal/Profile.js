const mongoose = require("mongoose");
const Schema = mongoose.Schema;

const UsersProfileSchema = new Schema({
  userRegData: {
    type: mongoose.Schema.Types.ObjectId,
    ref: "users"
  },
  handle: {
    type: String,
    required: true
  },

  website: {
    type: String
  },
  userid: {
    type: String
  },
  location: {
    type: String
  },
  bio: {
    type: String
  },
  skills: {
    type: [String],
    required: true
  },
  experience: [
    {
      position: {
        type: String,
        required: true
      },
      companyname: {
        type: String,
        required: true
      },
      location: {
        type: String,
        required: true
      },
      yearsofexperience: {
        type: String,
        required: true
      }
    }
  ],

  student: [
    {
      currentlyDoing: {
        type: String
      }
    }
  ],

  education: [
    {
      ssc: [
        {
          schoolName: {
            type: String
          },
          passingOutYear: {
            type: String
          },
          percentage: {
            type: String
          }
        }
      ],
      hsc: [
        {
          schoolName: {
            type: String
          },
          passingOutYear: {
            type: String
          },
          percentage: {
            type: String
          }
        }
      ],
      graduation: [
        {
          collegeName: {
            type: String
          },
          stream: {
            type: String
          },
          passingOutYear: {
            type: String
          },
          percentage: {
            type: String
          }
        }
      ]
    }
  ],
  date: {
    type: Date,
    default: Date.now
  }
});

module.exports = Profile = mongoose.model("userprofile", UsersProfileSchema);
