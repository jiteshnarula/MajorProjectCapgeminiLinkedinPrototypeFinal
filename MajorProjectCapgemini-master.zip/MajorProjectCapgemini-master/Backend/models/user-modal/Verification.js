const mongoose = require("mongoose");
const Schema = mongoose.Schema;

const VerificationSchema = new Schema([
  {
    verificationotp: {
      type: String,
      required: true
    },
    userid: {
      type: String,
      required: true
    },
    email: {
      type: String
    }
  }
]);

module.exports = User = mongoose.model("otpverification", VerificationSchema);
