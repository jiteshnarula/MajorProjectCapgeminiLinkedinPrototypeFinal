const express = require("express");
const router = express.Router();
const mongoose = require("mongoose");

//importing profile model
const Profile = require("../../../models/user-modal/Profile");
//importing user registeration model
const User = require("../../../models/user-modal/UsersRegisteration");
//import FriendRequest modal
const FriendRequest = require("../../../models/user-modal/FriendRequest");



router.get("/test", (req, res) => {
  res.send("everything is fine");
});




//getting request list
router.get("/gettingfriends/:userid", (req, res) => {
  FriendRequest.find({ userid: req.params.userid })
    .then(user => {
      res.json(user);
    })
    .catch(err => {
      console.log(err);
    });
});

//user 1 send the request to user 2
router.post("/sendrequest/:user1/:user2", (req, res) => {
  const requestList = {
    userid: req.params.user2
  };
  const requestedList = {};
  const friendList = {};
  const newFriendRequest = new FriendRequest({
    userid: req.params.user1,
    requestList: requestList
  });
  console.log(newFriendRequest);
  newFriendRequest.save().then(sendingRequest => res.json(sendingRequest));

  //logged in as user 2
  const requestList2 = {};
  const requestedList2 = {
    userid: req.params.user1
  };
  const friendList2 = {};
  const newFriendRequest2 = new FriendRequest({
    userid: req.params.user2,
    requestedList: requestedList2
  });
  console.log(newFriendRequest2);
  newFriendRequest2.save().then(sendingRequest => res.json(sendingRequest));
});

//user2 accepts the request of user1
router.delete("/acceptrequest/:user1/:user2", (req, res) => {
  //delting the friendid from requestlist of user1
  console.log(req.params.user1);

  FriendRequest.findOne({ userid: req.params.user1 })
    .then(friendRequest => {
      const removeFriend = friendRequest.requestList
        .map(item => item.userid)
        .indexOf(req.params.user2);

      console.log(removeFriend);

      // //splice the array
      friendRequest.requestList.splice(removeFriend, 1);
      console.log("After " + friendRequest.requestList);

      // friendRequest.friendList.push(req.params.user2)

      //    friendRequest.friendList.unshift(req.params.user2);
      //save

      friendRequest.save().then(friendList => {
        console.log(friendList);
        res.json(friendList);
      });

      friendRequest.friendList.unshift({ userid: req.params.user2 });

      friendRequest.save().then(friendList => {
        console.log(friendList);
        res.json(friendList);
      });
    })
    .catch(err => {
      // res.status(404).json(err)
    });

  //delting the friendid from requestedList of user2

  console.log(req.params.user2);

  FriendRequest.findOne({ userid: req.params.user2 })
    .then(friendRequest => {
      const removeFriend = friendRequest.requestedList
        .map(item => item.userid)
        .indexOf(req.params.user1);
      console.log(removeFriend);

      // //splice the array
      friendRequest.requestedList.splice(removeFriend, 1);
      console.log("After " + friendRequest.requestedList);
      //save
      friendRequest.save().then(friendList => {
        console.log(friendList);
        res.json(friendList);
      });

      friendRequest.friendList.unshift({ userid: req.params.user1 });

      friendRequest.save().then(friendList => {
        console.log(friendList);
        res.json(friendList);
      });
    })
    .catch(err => {
      res.status(404).json(err);
    });
});

module.exports = router;
