const express = require("express");
const router = express.Router();
const mongoose = require("mongoose");
const nodemailer = require("nodemailer");
var smtpTransport = require("nodemailer-smtp-transport");

//importing verification model
const Verification = require("../../../models/user-modal/Verification");

//otp verification
router.post("/verification/:userid", (req, res) => {
  const verification = new Verification({
    verificationotp: req.body.verificationotp,
    userid: req.params.userid,
    email: req.body.email.toString()
  });
  console.log(verification);
  verification
    .save()
    .then(user => res.json(user))
    .catch(err => console.log(err));

  const output = `
    <h1>Hello from 8bit Team </h1>    
    <h2>Please enter this OTP to verify yourself  </h1>
    <h3>Your OTP is :  ${req.body.verificationotp}</h3>
    `;

  // create reusable transporter object using the default SMTP transport
  var transporter = nodemailer.createTransport(
   smtpTransport({
      service: "gmail",
      host: "smtp.gmail.com",
      auth: {
        user: "linkedinprototypecheck@gmail.com",
        pass: "789456123psjc"
      }
    })
  );

  var mailOptions = {
     from: "linkedinprototypecheck@gmail.com",
    to: req.body.email.toString(),
    subject: "Verificaton Mail",
    text: "That was easy!",
    html: output
  };

  transporter.sendMail(mailOptions, function(error, info) {
    if (error) {
      console.log(error);
    } else {
      console.log("Email sent: " + info.response);
    }
  });
});

//get the otp
router.get("/gettingotp/:userid", (req, res) => {
  Verification.findOne({ userid: req.params.userid }).then(verification => {
    res.json(verification);
  });
});

//checking the otp
router.get("/checkingotp/:userid/:otp", (req, res) => {
  Verification.find({ userid: req.params.userid })
    .then(verification => {
      console.log(verification);

      if (
        verification[0].verificationotp.toString().trim() ===
        req.params.otp.toString()
      ) {
        res.json({ msg: "Verification Success", status: 1 });
      } else {
        res.json({ msg: "wrong entered otp", status: 0 });
      }
    })
    .catch(err => {
      res.status(404).json({ message: "verification error" });
    });
});

//user2 accepts the request of user1
router.delete("/otpdeletion/:userid", (req, res) => {
  Verification.deleteOne({ userid: req.params.userid }, (err, result) => {
    if (err) {
      res.json(err);
    } else {
      res.json(result);
    }
  });

  //delting the friendid from requestedList of user2

  // console.log(req.params.user2);

  // FriendRequest.findOne({ userid: req.params.user2 })
  //   .then(friendRequest => {
  //     const removeFriend = friendRequest.requestedList
  //       .map(item => item.userid)
  //       .indexOf(req.params.user1);
  //     console.log(removeFriend);

  //     // //splice the array
  //     friendRequest.requestedList.splice(removeFriend, 1);
  //     console.log("After " + friendRequest.requestedList);
  //     //save
  //     friendRequest.save().then(friendList => {
  //       console.log(friendList);
  //       res.json(friendList);
  //     });

  //     friendRequest.friendList.unshift({ userid: req.params.user1 });

  //     friendRequest.save().then(friendList => {
  //       console.log(friendList);
  //       res.json(friendList);
  //     });
  //   })
  //   .catch(err => {
  //     res.status(404).json(err);
  //   });
});

module.exports = router;
