const express = require("express");
const router = express.Router();
const mongoose = require("mongoose");
const Post = require("../../../models/user-modal/Post");
const Profile = require("../../../models/user-modal/Profile");

// Test route
router.get("/test", (req, res) => {
  res.json({
    message: "Everything is okay"
  });
});

//create Post
router.post("/:id", (req, res) => {
  const id = req.params.id;
  const newPost = new Post({
    message: req.body.message.toString(),
    name: req.body.name.toString(),
    userimage: req.body.userimage,
    userid: id
  });

  newPost.save().then(post => res.json(post));
});

//get all the Posts
router.get("/", (req, res) => {
  Post.find()
    .sort({ date: -1 }) // sorting according to date asc or desc
    .then(posts => res.json(posts))
    .catch(err => {
      res.status(404).json({ message: "Post not found" });
    });
});

//get the post according to postid only
router.get("/:id", (req, res) => {
  Post.findById(req.params.id)
    .then(post => res.json(post))
    .catch(err => {
      res.status(404).json({ message: "Post not found" });
    });
});
//get the post according to userid only
router.get("/gettingpostonuserid/:userid", (req, res) => {
  Post.find({ userid: req.params.userid })
    .then(post => res.json(post))
    .catch(err => {
      res.status(404).json({ message: "Post not found" });
    });
});

//delete the post according to the id
router.delete("/:userid/:postid", (req, res) => {
  Profile.findOne({ userid: req.params.userid })
    .then(profile => {
      Post.findById(req.params.postid).then(post => {
        //checking the post owner
        if (post.userid.toString() !== req.params.userid) {
          return res.status(401).json({ Authorization: "False" });
        }
        //Delete
        post.remove().then(() => res.json({ success: true }));
      });
    })
    .catch(err => res.status(404).json({ message: "Post not found" }));
});

//Add likes
router.post("/like/:userid/:postid", (req, res) => {
  Profile.findOne({ userid: req.params.userid })
    .then(profile => {
      Post.findById(req.params.postid).then(post => {
        //checking if the id of the user already exist or not
        if (
          post.likes.filter(like => like.userid === req.params.userid).length >
          0
        ) {
          return res
            .status(400)
            .json({ alreadyLiked: "User already liked this post" });
        }

        // add userid to likes array
        post.likes.unshift({ userid: req.params.userid });
        post.save().then(post => res.json(post));
      });
    })
    .catch(err => res.status(404).json({ message: "Post not found" }));
});

// remove Likes
router.post("/unlike/:userid/:postid", (req, res) => {
  Profile.findOne({ userid: req.params.userid })
    .then(profile => {
      Post.findById(req.params.postid).then(post => {
        //checking if the id of the user already exist or not
        if (
          post.likes.filter(like => like.userid === req.params.userid)
            .length === 0
        ) {
          return res
            .status(400)
            .json({ notLiked: "You have not liked this post" });
        }

        // get remove index
        const removeIndex = post.likes.map(item => item.user);
        console.log(removeIndex);
        post.likes.splice(removeIndex, 1);
        post.save().then(post => res.json(post));
      });
    })
    .catch(err => res.status(404).json({ message: "Post not found" }));
});

//Add Comment
router.post("/comment/:userid/:postid", (req, res) => {
  Post.findById(req.params.postid)
    .then(post => {
      const newComment = {
        message: req.body.message,
        name: req.body.name,
        userid: req.params.postid
      };

      //Add to comments array

      post.comments.unshift(newComment);
      post.save().then(post => res.json(post));
    })
    .catch(err => res.status(404).json({ postnotfound: "No post found " }));
});

//Delete Comment
router.delete("/delcomment/:userid/:postid/:commentid", (req, res) => {
  Post.findById(req.params.postid)
    .then(post => {
      //check if comment exist
      if (
        post.comments.filter(
          comment => comment._id.toString() === req.params.commentid
        ).length === 0
      ) {
        return res
          .status(404)
          .json({ commentnotexist: "Comment doesnot exist" });
      }

      //Get remove index
      const removeIndex = post.comments
        .map(item => item._id.toString())
        .indexOf(req.params.commentid);

      //splice the comment from array

      post.comments.splice(removeIndex, 1);

      post.save().then(post => res.json(post));
    })
    .catch(err => res.status(404).json({ postnotfound: "No comment found " }));
});

module.exports = router;
