const express = require("express");
const router = express.Router();
const mongoose = require("mongoose");

//importing profile model
const Profile = require("../../../models/user-modal/Profile");
//importing user registeration model
const User = require("../../../models/user-modal/UsersRegisteration");

//Test route
router.get("/test", (req, res) => {
  res.json({
    message: "Everything is okay"
  });
});

router.post("/allProfilesExceptFriends", (req, res) => {
  console.log(req.body.list);
  Profile.find({ userid: { $nin: req.body.list } })
    .then(profile => {
      console.log(profile);
      res.json(profile);
    })
    .catch(err => res.status(404).json("There are no profiles"));
});

//getting all the profile except one
router.get("/allProfilesExceptOne/:userid", (req, res) => {
  Profile.find({ userid: { $nin: [req.params.userid] } })
    .then(profile => {
      console.log(profile);
      if (!profile) {
        res.status(404).json("There are no profiles");
      }
      res.json(profile);
    })
    .catch(err => res.status(404).json("There are no profiles"));
});

//gettig all the profiles
//getting profile through id only
router.get("/allProfiles", (req, res) => {
  Profile.find()
    .populate("users", ["name"])
    .then(profile => {
      console.log(profile);
      if (!profile) {
        res.status(404).json("There are no profiles");
      }
      res.json(profile);
    })
    .catch(err => res.status(404).json("There are no profiles"));
});

//getting profile on the basis of id
router.get("/:id", (req, res) => {
  var id = req.params.id;
  console.log(id);
  Profile.findOne({
    userid: req.params.id
  })
    .populate("userRegData")
    .then(profile => {
      if (!profile) {
        return res.status(404).json({
          msg: "There is no profile belongs to this user",
          status: 0
        });
      }
      res.json(profile);
    })
    .catch(err => {
      res.status(404).json(err);
    });
});

//adding profiles or update profile on the basis of id
router.post("/:id", (req, res) => {
  var id = req.params.id;
  const profileFields = {};

  console.log(req.body.handle);

  profileFields.userid = id;
  if (req.body.handle) {
    profileFields.handle = req.body.handle.toString();
  }

  if (req.body.website) {
    profileFields.website = req.body.website.toString();
  }
  if (req.body.location) {
    profileFields.location = req.body.location.toString();
  }
  if (req.body.bio) {
    profileFields.bio = req.body.bio.toString();
  }
  //skills spliting the comma seprated values
  console.log(typeof req.body.skills);
  if (typeof req.body.skills !== "undefined") {
    profileFields.skills = req.body.skills.toString().split(",");
  }

  //logged in user
  Profile.findOne({
    userid: req.params.id
  }).then(profile => {
    console.log(profile);
    if (profile) {
      //update the profile
      console.log("Upading");
      Profile.findOneAndUpdate(
        {
          userid: id
        },
        {
          $set: profileFields
        },
        {
          new: true
        }
      ).then(profile => {
        res.json(profile);
      });
    } else {
      //create the profile
      //check if handle exist
      console.log("Creating");
      Profile.findOne({
        handle: profileFields.handle
      }).then(profile => {
        if (profile) {
          res.status(400).json({
            message: "That handle already exist",
            status: 0
          });
        }
        //Save Profile
        new Profile(profileFields).save().then(profile => res.json(profile));
      });
    }
  });
});

//getting profile through handle
router.get("/handle/:handle", (req, res) => {
  Profile.findOne({
    handle: req.params.handle
  })
    .populate("user", ["name", "userimage"])
    .then(profile => {
      if (!profile) {
        res.status(404).json("There is no profile for this handle");
      }
      res.json(profile);
    })
    .catch(err => res.status(404).json(err));
});

//getting profile through id only
router.get("/user/:user_id", (req, res) => {
  Profile.findOne({
    userid: req.params.user_id
  })
    .populate("user", ["name", "userimage"])
    .then(profile => {
      if (!profile) {
        res.status(404).json("There is no profile for this id");
      }
      res.json(profile);
    })
    .catch(err => res.status(404).json("There is no profile with this id"));
});

//experiance
router.post("/experience/:id", (req, res) => {
  Profile.findOne({
    userid: req.params.id
  }).then(profile => {
    console.log(profile);
    console.log(
      req.body.position +
        "\n" +
        req.body.companyname +
        "\n" +
        req.body.location +
        "\n" +
        req.body.yearsofexperience
    );
    const newExp = {
      position: req.body.position,
      companyname: req.body.companyname,
      location: req.body.location.toString(),
      yearsofexperience: req.body.yearsofexperience.toString()
    };
    console.log(newExp);
    //adding to experiance array
    profile.experience.unshift(newExp);
    profile.save().then(profile => res.json(profile));
  });
});

//fresher
router.post("/fresher/:id", (req, res) => {
  Profile.findOne({
    userid: req.params.id
  }).then(profile => {
    const newWork = {
      currentlyDoing: req.body.currentwork
    };
    //adding to experiance array
    profile.student.unshift(newWork);
    profile.save().then(profile => res.json(profile));
  });
});

//education
router.post("/education/:id", (req, res) => {
  Profile.findOne({
    userid: req.params.id
  }).then(profile => {
    const ssc = {
      schoolName: req.body.sscschoolname.toString(),
      passingOutYear: req.body.sscpassingoutyear.toString(),
      percentage: req.body.sscpercentage.toString()
    };
    const hsc = {
      schoolName: req.body.hscschoolname.toString(),
      passingOutYear: req.body.hscpassingoutyear.toString(),
      percentage: req.body.hscpercentage.toString()
    };
    const graduation = {
      collegeName: req.body.collegename.toString(),
      stream: req.body.stream.toString(),
      passingOutYear: req.body.passingoutyear.toString(),
      percentage: req.body.percentage.toString()
    };

    const education = {
      ssc: ssc,
      hsc: hsc,
      graduation: graduation
    };
    //adding to experiance array
    profile.education.unshift(education);
    profile.save().then(profile => res.json(profile));
  });
});

//delete experience using experience id

router.delete("/experience/:exp_id/:user_id", (req, res) => {
  Profile.findOne({ userid: req.params.user_id })
    .then(profile => {
      const removeExperience = profile.experience
        .map(item => item.id)
        .indexOf(req.params.exp_id);

      console.log(profile.experience);

      //splice the array
      profile.experience.splice(removeExperience, 1);
      console.log(profile.experience);
      //save
      profile.save().then(profile => {
        console.log(profile);
        res.json(profile);
      });
    })
    .catch(err => {
      res.status(404).json(err);
    });
});

//delete education using education id
router.delete("/education/:edu_id/:user_id", (req, res) => {
  Profile.findOne({ userid: req.params.user_id })
    .then(profile => {
      const removeEducation = profile.education
        .map(item => item.id)
        .indexOf(req.params.edu_id);

      console.log(profile.education);

      //splice the array
      profile.education.splice(removeEducation, 1);
      console.log("After " + profile.experience);
      //save
      profile.save().then(profile => {
        console.log(profile);
        res.json(profile);
      });
    })
    .catch(err => {
      res.status(404).json(err);
    });
});

//user 1 send the request to user 2
router.post("/sendrequest/:myuserid/:frienduserid", (req, res) => {});

module.exports = router;
