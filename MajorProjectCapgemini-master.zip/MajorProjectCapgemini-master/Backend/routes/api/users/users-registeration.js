const express = require("express");
const router = express.Router();
// const multer = require("multer");
const bcrypt = require("bcryptjs");

//importing User modal
const User = require("../../../models/user-modal/UsersRegisteration");

// const storage = multer.diskStorage({
//   destination: (req, file, cb) => {
//     cb(null, "./uploads/");
//   },
//   filename: (req, file, cb) => {
//     const now = new Date().toISOString();
//     const date = now.replace(/:/g, "-");
//     cb(null, date + file.originalname);
//   }
// });

// const fileFilter = (req, file, cb) => {
//   if (
//     file.mimetype === "image/jpeg" ||
//     file.mimetype === "image/png" ||
//     file.mimetype === "image/png"
//   ) {
//     cb(null, true);
//   } else {
//     cb(new Error("Only png,jpg and jpeg file is accepted"), false);
//   }
// };

// const upload = multer({
//   storage: storage,
//   limits: {
//     fileSize: 1024 * 1024 * 5
//   },
//   fileFilter: fileFilter
// });

//Test route
router.get("/test", (req, res) => {
  res.send("Everythig is okay");
});


router.get("/gettingresgisteredusers/:emailid", (req, res) => {
  User.find({
    email: req.params.emailid
  })
    .then(user => {
      res.json(user);
    })
    .catch(err => {
      console.log(err);
    });
});



router.get("/registeredUsers/:userid", (req, res) => {
  User.find({
    _id: req.params.userid
  })
    .then(user => {
      res.json(user);
    })
    .catch(err => {
      console.log(err);
    });
});

//register routes
router.post("/register", (req, res) => {
  User.findOne({
    email: req.body.email
  }).then(user => {
    if (user) {
      return res.status(400).json({
        email: "Email already exist",
        error: 0
      });
    } else {
      const newUser = new User({
        name: req.body.name.toString(),
        email: req.body.email.toString(),
        phonenumber: req.body.phonenumber.toString(),
        // userimage: req.file.path,
        password: req.body.password.toString()
      });
      console.log(newUser);
      bcrypt.genSalt(10, (err, salt) => {
        bcrypt.hash(newUser.password, salt, (err, hash) => {
          if (err) throw err;
          (newUser.password = hash),
            newUser
              .save()
              .then(user => res.json({ user: user, status: 1 }))
              .catch(err => console.log(err));
        });
      });
    }
  });
});

//login route

router.post("/login", (req, res) => {
  email = req.body.email;
  password = req.body.password;
  console.log(email + password);

  User.findOne({
    email
  }).then(user => {
    console.log(user);
    if (!user) {
      res.json({
        email: "Email not found",
        status: 0
      });
    }

    bcrypt.compare(password.toString(), user.password).then(isMatch => {
      if (isMatch) {
        res.json({
          msg: " Login Success",
          status: 200
        });
      } else {
        return res.status(400).json({
          password: "Password Incorrect",
          status: 1
        });
      }
    });
  });
});

module.exports = router;
