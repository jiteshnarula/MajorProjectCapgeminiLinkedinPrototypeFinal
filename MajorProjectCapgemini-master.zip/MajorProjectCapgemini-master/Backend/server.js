const express = require("express");
const app = express();
const mongoose = require("mongoose");
const users = require("./routes/api/users/users-registeration");
const org = require("./routes/api/organization/org-registeration");
const profile = require("./routes/api/users/profile");
const posts = require("./routes/api/users/posts");
const friend = require("./routes/api/users/friend");
const verification = require("./routes/api/users/otpverification");
const bodyParser = require("body-parser");
var cors = require("cors");

// DB config

const db = require("./config/keys").mongoURL;
mongoose
  .connect(db, {
    useNewUrlParser: true
  })
  .then(() => console.log("Mongodb connected"))
  .catch(err => console.log(err));

app.get("/", (req, res) => {
  res.send("Hello from test route");
});

app.use(cors());

app.use(
  bodyParser.urlencoded({
    extended: false
  })
);
app.use(bodyParser.json());

app.use("/api/users", users);
app.use("/api/org", org);
app.use("/api/profile", profile);
app.use("/api/posts", posts);
app.use("/api/friend", friend);
app.use("/api/otp", verification);

const port = process.env.PORT || 6002;
app.listen(port, () => console.log(`Server is running on port ${port}`));
