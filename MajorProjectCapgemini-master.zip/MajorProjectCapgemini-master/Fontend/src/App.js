import React, { Component } from "react";
import { BrowserRouter as Router, Switch, Route, Link } from "react-router-dom";

import "./App.css";
import LandingComponent from "./components/LandingPage/LandingComponent";
import Login from "./components/loginPage/login";
import Register from "./components/registerationPage/register";
import Verification from "./components/otp-verification/verification";
import Navigation from "./components/User-Home/Navigation-Component/navigation";
import Notification from "./components/User-Home/noification/notifiaction";
import Network from "./components/User-Home/mynetwork/mynetwork";
import Home from "./components/User-Home/home/home";
import Profile from "./components/User-Home/profile/profile"; 
import Education from "./components/User-Home/profile/education/education";
import About from "./components/User-Home/profile/about/about";
import Experience from "./components/User-Home/profile/experience/experience";
// import chat from "./components/User-Home/chat/chat";
import Chatroom from "./components/User-Home/chat/Chatroom";
import chat from "./components/User-Home/chat/chat";
import ViewJobs from "./components/User-Home/jobs/viewjobs";
import ManageJobs from "./components/User-Home/jobs/managejobs";

class App extends Component {
  render() {
    return (
      <Router>
        <div className="App">
          <Switch>
            <Route exact path="/" component={LandingComponent} />
            <Route exact path="/register" component={Register} />
            <Route exact path="/login" component={Login} />
            <Route exact path="/verification" component={Verification} />
            <Route exact path="/homenavigation" component={Navigation} />
            <Route exact path="/home" component={Home} />
            <Route exact path="/profile" component={Profile} />
            <Route exact path="/jobs" component={ManageJobs} />
            <Route exact path="/notification" component={Notification} />
            <Route exact path="/mynetwork" component={Network} />
            <Route exact path="/exp" component={Experience} />
            <Route exact path="/education" component={Education} />
            <Route exact path="/about" component={About} />
            <Route exact path="/chat" component={chat} />
            <Route exact path="/viewjob" component={ViewJobs} />
            
          </Switch>
        </div>
      </Router>
    );
  }
}

export default App;
