import React, { Component } from "react";
import { Link } from "react-router-dom";

import NavigationComponent from "./NavigationComponent";
import FooteComponent from "./FooterComponent";

export default class LandingComponent extends Component {
  myStyle = {
    position: "relative",
    bottom: 0,
    padding: "2rem",
    width: "100%"
  };
  render() {
    return (
      <>
        <div>
          <NavigationComponent />
          <div className="row">
            <div className="col-lg-6 display-3 text-success">
              Welcome to your professional Community
            </div>

            <div className="col-lg-5">
              <img
                height="280"
                width="600"
                src={require("../../assets/landinpageimage2.jpg")}
              />
            </div>
          </div>
        </div>
{/* <div className="text-center">
        <Link to="/login" className="btn btn-primary">
          Login
        </Link>
        &nbsp;&nbsp;&nbsp;
        <Link to="/register" className="btn btn-primary">
          Register
        </Link>
</div> */}
        <div style={this.myStyle}>
          <FooteComponent />
        </div>
      </>
    );
  }
}
