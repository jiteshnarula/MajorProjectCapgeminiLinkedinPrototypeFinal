import React, { Component } from "react";
import { Link } from "react-router-dom";
import Modal from "react-modal";
import { Tab, Tabs, TabList, TabPanel } from "react-tabs";
import "react-tabs/style/react-tabs.css";
import Register from "../registerationPage/register";
import Login from "../loginPage/login";

class NavigationComponent extends Component {
  constructor() {
    super();
    this.state = {
      modalVisible: false,
      loginModalVisible: false
    };
  }

  customStyles = {
    content: {
      top: "50%",
      left: "50%",
      right: "auto",
      bottom: "auto",
      marginRight: "-50%",
      transform: "translate(-50%, -50%)"
    }
  };

  // TO make the modal more accessible
  componentWillMount() {
    Modal.setAppElement("body");
  }

  getJoinNowModal = e => {
    e.preventDefault();
    this.setState({
      modalVisible: !this.state.modalVisible
    });
  };

  getLoginModal = e => {
    e.preventDefault();
    this.setState({
      loginModalVisible: !this.state.loginModalVisible
    });
  };

  render() {
    return (
      <div>
        <nav className="navbar navbar-expand-lg navbar-dark bg-dark">
          <a className="navbar-brand text-white" href="#">
            8BitTeam
          </a>
          <img
            height="50"
            src={require("../../assets/output-onlinepngtools.png")}
          />
          <button
            className="navbar-toggler"
            type="button"
            data-toggle="collapse"
            data-target="#navbarSupportedContent"
            aria-controls="navbarSupportedContent"
            aria-expanded="false"
            aria-label="Toggle navigation"
          >
            <span className="navbar-toggler-icon" />
          </button>

          <div className="collapse navbar-collapse" id="navbarSupportedContent">
            <ul className="navbar-nav mr-auto" />
            <form className="form-inline my-2 my-lg-0">
              <Link
                className="btn btn-success my-2 my-sm-0"
                type="submit"
                to="/register"
              >
                Join Now
              </Link>{" "}
              &nbsp;&nbsp;
              <Link
                className="btn btn-success   my-2 my-sm-0"
                type="submit"
                to="/login"
              >
                Log In
              </Link>
            </form>
          </div>
        </nav>
      </div>
    );
  }
}
export default NavigationComponent;
