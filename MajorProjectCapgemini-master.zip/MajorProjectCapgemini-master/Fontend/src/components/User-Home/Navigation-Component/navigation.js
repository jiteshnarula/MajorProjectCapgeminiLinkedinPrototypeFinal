import React, { Component } from "react";
import { Link } from "react-router-dom";
import { browserHistory } from "react-router";

class Navigation extends Component {
  constructor(props) {
    super(props);
    // this.onLogout = this.onLogout.bind(this);
  }

  // onLogout(e) {
  //   e.preventDefault();
  //   this.props.history.push("/login");
  // }

  render() {
    return (
      <div>
        <nav className="navbar navbar-expand-lg navbar-dark bg-dark">
          <a className="navbar-brand text-white" href="#">
            8BitTeam
          </a>
          <img
            height="50"
            src={require("../../../assets/output-onlinepngtools.png")}
          />
          <div class="search-container">
            <input type="text" className="text-center" placeholder="Search" />
          </div>
          &nbsp;
          <button className="btn btn-warning">
            <i className=" fas fa-search fa-2x" variant="outline-info" />
          </button>
          <div
            className="collapse navbar-collapse"
            id="bs-example-navbar-collapse-1"
          >
            <ul className="nav navbar-nav navbar-right">
              &nbsp;&nbsp;&nbsp;&nbsp;
              <li>
                <Link className="fas fa-home fa-3x" to="/home" />
              </li>
              &nbsp;&nbsp;&nbsp;&nbsp;
              <li>
                <Link className="fas fa-briefcase fa-3x" to="/jobs" />
                <span className="sr-only" />
              </li>
              &nbsp;&nbsp;&nbsp;&nbsp;
              <li>
                <Link className="fas fa-users fa-3x" to="/mynetwork" />
              </li>
              &nbsp;&nbsp;&nbsp;&nbsp;
              <li>
                <Link className="fas fa-user fa-3x" to="/profile" />
              </li>
              &nbsp;&nbsp;&nbsp;&nbsp;
              <li>
                <Link className="fa fa-bell fa-3x" to="/notification">
                  &nbsp;&nbsp;
                </Link>
              </li>
              <li>
                <Link className="fas fa-comments fa-3x" to="/chat" />
              </li>
            </ul>
          </div>
          <div className="collapse navbar-collapse" id="navbarSupportedContent">
            <ul className="navbar-nav mr-auto" />
            <form className="form-inline my-2 my-lg-0">
              &nbsp;&nbsp;
              <Link
                className="btn btn-danger   my-2 my-sm-0"
                type="submit"
                to="/"
              >
                Log Out
              </Link>
            </form>
          </div>
        </nav>
      </div>
    );
  }
}

export default Navigation;
