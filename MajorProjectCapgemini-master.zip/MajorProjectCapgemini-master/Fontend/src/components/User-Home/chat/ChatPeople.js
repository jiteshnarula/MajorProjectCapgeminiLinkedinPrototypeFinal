import React from 'react';
import ReactDOM from 'react-dom';
import './Chat.css'
import axios from 'axios'

const initialState = {
    message: "",
    // userimage: "",
    messageError: "",
    // userimageError: "",
    friendList: [],
    name: "",
    finalFriendList: "",
    posttoSHow: "",
    friendName : []
  };
class ChatPeople extends React.Component {
   
    constructor(props) {
        super(props);
        // this.routeChangeHome = this.routeChangeHome.bind(this);
        this.state = initialState;
        // this.onSubmit = this.onSubmit.bind(this);
        // this.onChange = this.onChange.bind(this);
      }

        componentDidMount(){
            axios
            .get(
              `http://localhost:6002/api/friend/gettingfriends/${localStorage.getItem(
                "userid"
              )}`
            )
            .then(res => {
              // console.log(res.data);
              res.data.map((object, i) => {
                object.friendList.map((object, i) => {
                  console.log(object.userid);
                  this.setState({
                    friendList: [...this.state.friendList, object.userid]
                  });
                });
                console.log("Friend Request" + this.state.friendList);
              });
              console.log(localStorage.getItem("userid"));
              this.setState({
                friendList: [...this.state.friendList, localStorage.getItem("userid")]
              });
              console.log(" after Friend Request" + this.state.friendList);
              let unique = [...new Set(this.state.friendList)];
              console.log(unique);
              this.setState({
                finalFriendList: unique
              });

              this.state.finalFriendList.map((object,i)=>{
                axios.get(`http://localhost:6002/api/users/registeredUsers/${object}`)
                .then(res =>{
                    res.data.map((object,i)=>{
                        console.log(object.name)
                        this.setState({
                            friendName : [...this.state.friendName,object.name]
                        })
                    })
                })
            })


              console.log(this.state.finalFriendList);
            })


           


    
        }




    render(){

    
        return(
            <div className="chatpeople">
                 <h1>People</h1>
                 <ul>
                 {
                     this.state.friendName.map((object,i)=>{
                      return   <li>{object}</li>       
                     })
                 } 
                 </ul>
            </div>
           
        )
    }
}

export default ChatPeople;