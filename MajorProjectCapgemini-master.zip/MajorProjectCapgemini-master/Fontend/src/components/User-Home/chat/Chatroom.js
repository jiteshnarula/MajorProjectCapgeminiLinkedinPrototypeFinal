import React from 'react';
import ReactDOM from 'react-dom';
import './Chat.css'

import Message from './Message.js';
import Navigation from '../Navigation-Component/navigation';

class Chatroom extends React.Component {
    constructor(props) {
        super(props);

        this.state = {
            chats: [ ]
        };

        this.submitMessage = this.submitMessage.bind(this);
        // this.submitOppMessage = this.submitOppMessage.bind(this);
    }

    componentDidMount() {
        this.scrollToBot();
    }

    componentDidUpdate() {
        this.scrollToBot();
    }

    scrollToBot() {
        ReactDOM.findDOMNode(this.refs.chats).scrollTop = ReactDOM.findDOMNode(this.refs.chats).scrollHeight;
    }

    // submitMessage(e) {
    //     e.preventDefault();

    //     this.setState({
    //         chats: this.state.chats.concat([{
    //             username: "Alice Chen",
    //             content: <p>{ReactDOM.findDOMNode(this.refs.msg).value}</p>,
    //             img: "http://i.imgur.com/Tj5DGiO.jpg",
    //         }])
    //     }, () => {
    //         ReactDOM.findDOMNode(this.refs.msg).value = "";
    //     });
    // }

    submitMessage(e) {
        e.preventDefault();

        this.setState({
            chats: this.state.chats.concat([{
                username: "Kevin Hsu",
                content: <p>{ReactDOM.findDOMNode(this.refs.msg).value}</p>,
                img: "http://i.imgur.com/Tj5DGiO.jpg",
            }])
        }, () => {
            ReactDOM.findDOMNode(this.refs.msg).value = "";
        });
    }

    render() {
        const username = "Kevin Hsu";
        const { chats } = this.state;

        return (
            <div> 
            <div className="chatroom">
                <div className="col-lg-6"></div>
                <h3>Chat Box</h3>
                <ul className="chats" ref="chats">
                    {
                        chats.map((chat) => 
                            <Message chat={chat} user={username} />
                        )
                    }
                    {

                    }
                </ul>
                <form className="input" onSubmit={(e) => this.submitMessage(e)}>
                    <input type="text" ref="msg" />
                    <input type="submit" value="Submit" />
                </form>
                <div>
                {/* <form className="input" onSubmit={(e) => this.submitOppMessage(e)}>
                    <input type="text" ref="msg" />
                    <input type="submit" value="Submit" />
                </form> */}

                </div>
            </div>
            </div>
        );
    }
}

export default Chatroom;