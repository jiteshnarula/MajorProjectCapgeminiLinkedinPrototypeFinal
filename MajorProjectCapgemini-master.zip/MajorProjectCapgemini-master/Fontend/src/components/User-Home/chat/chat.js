import React, { Component } from 'react'
import Navigation from '../Navigation-Component/navigation';
import Chatroom from './Chatroom';
import ChatPeople from './ChatPeople';

export default class chat extends Component {
  render() {
    return (
      <div>
          <Navigation/>
          
         
          <div className="row">
         
          <div className="col-lg-4">
          <ChatPeople/>
         
          </div>
          <div className="col-lg-8">
          
          <Chatroom/>
          </div>
         

         

         
          </div>
          
          
      </div>
    )
  }
}
