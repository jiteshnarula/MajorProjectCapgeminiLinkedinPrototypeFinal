import React, { Component } from "react";
import Navigation from "../Navigation-Component/navigation";
import axios from "axios";

const initialState = {
  message: "",
  // userimage: "",
  messageError: "",
  // userimageError: "",
  friendList: [],
  name: "",
  finalFriendList: "",
  posttoSHow: "",
  likes:"",
  comment: ""
};
class Home extends Component {
  constructor(props) {
    super(props);
    // this.routeChangeHome = this.routeChangeHome.bind(this);
    this.state = initialState;
    this.onSubmit = this.onSubmit.bind(this);
    this.onChange = this.onChange.bind(this);
    this.likeButton = this.likeButton.bind(this);
    this.dislikeButton  =  this.dislikeButton.bind(this);
    this.sendButton = this.sendButton.bind(this);
   


  }
  componentDidMount() {
    
    axios
      .get(
        `http://localhost:6002/api/friend/gettingfriends/${localStorage.getItem(
          "userid"
        )}`
      )
      .then(res => {
        // console.log(res.data);
        res.data.map((object, i) => {
          object.friendList.map((object, i) => {
            console.log(object.userid);
            this.setState({
              friendList: [...this.state.friendList, object.userid]
            });
          });
          console.log("Friend Request" + this.state.friendList);
        });
        console.log(localStorage.getItem("userid"));
        this.setState({
          friendList: [...this.state.friendList, localStorage.getItem("userid")]
        });
        console.log(" after Friend Request" + this.state.friendList);
        let unique = [...new Set(this.state.friendList)];
        console.log(unique);
        this.setState({
          finalFriendList: unique
        });
        console.log(this.state.finalFriendList);

        this.state.finalFriendList.map((object, i) => {
          axios
            .get(
              `http://localhost:6002/api/posts/gettingpostonuserid/${object}`
            )
            .then(res => {
              console.log(res.data);
              res.data.map((object, i) => {
                console.log(object);
                this.setState({
                  posttoSHow: [...this.state.posttoSHow, object]
                });

                console.log(this.state.posttoSHow);
              });
            })
            .catch(err => {
              console.log(err);
            });
        });
      })
      .catch(err => {
        console.log(err);
      });
  }
  onChange(e) {
    this.setState({ [e.target.name]: [e.target.value] });
  }

  validate = () => {
    let messageError = "";
    // let userimageError = "";

    if (!this.state.message) {
      messageError = "message Cannot be blank";
    }

    // if (!this.state.userimage) {
    //   userimageError = "Userimage cannot be blank";
    // }

    if (messageError) {
      this.setState({
        messageError
      });
      return false;
    }

    return true;
  };



  onSubmit(e) {
    e.preventDefault();

    // let fd = new FormData();
    // console.log(this.state.userimage);
    // fd.append("userimage", this.state.userimage);
    // console.log(fd);
    // const config = { headers: { "Content-Type": "multipart/form-data" } };

    axios
      .get(
        `http://localhost:6002/api/users/registeredUsers/${localStorage.getItem(
          "userid"
        )}`
      )
      .then(user => {
        console.log(user.data);
        user.data.map((object, i) => {
          this.setState({
            name: object.name
          });
          var valueObject = {
            name: object.name,
            message: this.state.message
            // userid: localStorage.getItem("userid")
            // userimage: fd
          };
          const isValid = this.validate();
          if (isValid) {
            console.log(valueObject);
            this.setState(initialState);

            axios
              .post(
                `http://localhost:6002/api/posts/${localStorage.getItem(
                  "userid"
                )}`,
                valueObject
              )
              .then(res => {
                console.log(res.data);

                // this.setState(initialState);
                alert("You have successfully posted");
                window.location.reload();
              });
          }
        });
      })
      .catch(err => {
        console.log(err);
      });
  }



  likeButton(userid,postid){
    // alert(userid+","+postid)

    axios.post(`http://localhost:6002/api/posts/like/${userid}/${postid}`)
    .then(res => {
      res.data.map((object,i)=>{
        console.log(object)
        // this.setState({
        //   likes : object.likes.length
        // })
      })
       
    })
    .catch(err =>{
      console.log(err)
    })
    window.location.reload();
  }
  dislikeButton(userid,postid){
    // /unlike/:userid/:postid
    axios.post(`http://localhost:6002/api/posts/unlike/${userid}/${postid}`)
    .then(res => {
      res.data.map((object,i)=>{
        console.log(object)
        // this.setState({
        //   likes : object.likes.length
        // })
        window.location.reload();
      })
       
    })
    .catch(err =>{
      console.log(err)
    })
    window.location.reload();
  }
  sendButton(){
    alert("3")
  }
  

  render() {
    var style = {
      border: "30px solid green",
      borderRightColor: "red"
    };
    return (
      <div>
        <Navigation />


        <div className="container">
          <div className="row">
            <div className="col-lg-12">
              <br />
              <br />
              <form onSubmit={this.onSubmit}>
                <div className="card">
                  <div className="container">
                    <br />
                    <textarea
                      row="50"
                      cols="150"
                      placeholder="Share your thoughts"
                      name="message"
                      value={this.state.message}
                      onChange={this.onChange}
                    />
                    {this.state.messageError ? (
                      <div className="alert alert-danger" role="alert">
                        {this.state.messageError}
                      </div>
                    ) : null}
                    <br />
                    <button className="btn btn-success">Post</button>
                    <br />
                  </div>
                </div>
              </form>
            </div>
          </div>
        </div>
        {/* 
        <div className="card">
            Name
        </div> */}

        {this.state.posttoSHow
          ? this.state.posttoSHow.map((object, i) => {
              return (
                <div className="container">
                  <div className="row">
              
                    <div className="col-lg-8">
                    <br />  
                      <div class="card">
                        <div class="card-header">
                         <h3 className="text-primary"><u>{object.name}</u></h3>
                        </div>
                        <div class="card-body">
                          <p className="lead">{object.message}</p>
                        </div>
                        <div class="card-footer">
                          <button className="btn btn-link" 
                          onClick={()=>this.likeButton(object.userid,object._id)}>Like
                          <span class="badge badge-light">{object.likes.length}</span></button>

                          <button className="btn btn-link" 
                          onClick={ () => this.dislikeButton(object.userid,object._id)}>Dislike</button>

                        </div> 
 
                      </div>
                      
                    </div>
                  </div>
                </div>
              );
            })
          : null}
      </div>
    );
  }
}

export default Home;
