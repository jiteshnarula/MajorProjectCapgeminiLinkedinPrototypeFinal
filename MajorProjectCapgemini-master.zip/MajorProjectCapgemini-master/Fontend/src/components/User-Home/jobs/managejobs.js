import React, { Component } from "react"; 
import Navigation from "../Navigation-Component/navigation";
import {Link} from 'react-router-dom'
class ManageJobs extends Component {
  render() {
    return (
      <div> 
        <Navigation/>
        {/* <div className="jumbotron text-center">
          <h2>Create a new job post </h2>

          <br />

          <h6>Get your open role in front of qualified candidates.</h6>

          <br />

          <div className="col-md-20">
            <a href="/PostJob" type="submit" className="btn btn-lg btn-primary" value="post a job">
              Post a Job
            </a>
          </div>
        </div> */}

        <hr />

        <div className="card-columns">
          <div className="card bg-warning">
            <div className="card-body text-center">
              <p className="card-text">
                <div className="card">
                  <img
                    className="img"
                    height="100px"
                    width="10%"
                    src={require("./img1.jpg")}
                  />

                  <div className="container">
                    <h4>
                      <b>John Doe</b>
                    </h4>

                    <p>Architect & Engineer</p>

                    <div className="col-md-20">
                      <Link
                       
                        type="submit"
                        className="btn btn-lg btn-primary"
                        value="post a job"
                        to="/viewjob"
                      >
                        View Job
                      </Link>
                    </div>
                  </div>
                </div>
              </p>
            </div>
          </div>
        </div>

        <footer>
          <p>
            <i>
              By using this site, you agree to LinkedIn terms of use. Commercial use of this site
              without express authorizationis prohibited. LinkedIn Corporation © 2019
            </i>
          </p>
        </footer>
      </div>
    );
  }
}

export default ManageJobs;
