import React, { Component } from "react";
import Navigation from "../Navigation-Component/navigation";
import axios from "axios";
import { createSocket } from "dgram";

class Network extends Component {
  constructor(props) {
    super(props);
    this.state = {
      users: "",
      profile: "",
      friendlist: "",
      requestedList: [],
      requestList: [],
      friendList: [],
      finalremoveArray: [],
      showUserID: [],
      showProfile: []
    };
  }

  componentDidMount() {
    axios
      .get(
        `http://localhost:6002/api/friend/gettingfriends/${localStorage.getItem(
          "userid"
        )}`
      )
      .then(res => {
        // console.log(res.data);
        res.data.map((object, i) => {
          // console.log(object);
          // console.log(object.requestedList);
          object.requestedList.map((object, i) => {
            console.log(object.userid);
            this.setState({
              requestedList: [...this.state.requestedList, object.userid]
            });
          });

          // console.log(this.state.requestedList);
          object.requestList.map((object, i) => {
            // console.log(object.userid);
            this.setState({
              requestList: [...this.state.requestList, object.userid]
            });
          });
          // console.log("RequestList" + this.state.requestList);

          console.log("Requested List" + this.state.requestedList);
          object.friendList.map((object, i) => {
            console.log(object.userid);
            this.setState({
              friendList: [...this.state.friendList, object.userid]
            });
          });
          // console.log("Friend Request" + this.state.friendList);
        });
      })
      .catch(err => {
        console.log(err);
      });

    axios
      .get(
        `http://localhost:6002/api/profile/allProfilesExceptOne/${localStorage.getItem(
          "userid"
        )}`
      )
      .then(res => {
        this.setState({
          profile: res.data
        });
        // console.log(this.state.profile);

        console.log("RequestList" + this.state.requestList);
        console.log("Requested List" + this.state.requestedList);
        console.log("Friend List" + this.state.friendList);

        var midArray = this.state.requestList.concat(this.state.requestedList);
        console.log("midArray" + midArray);

        const finalArray = midArray.concat(this.state.friendList);
        console.log("FInal Array", finalArray);
        const finalArray2 = finalArray.concat(localStorage.getItem("userid"));

        var filteredArray = finalArray2.filter(function(item, pos) {
          return finalArray2.indexOf(item) == pos;
        });
        console.log("after combining 2" + filteredArray);
        this.setState({
          finalremoveArray: filteredArray
        });

        const valueObject = { list: this.state.finalremoveArray };

        this.state.profile.map((object, i) => {
           
          axios
            .post(
              `http://localhost:6002/api/profile/allProfilesExceptFriends`,
              valueObject
            )
            .then(res => {
               
              res.data.map((object, i) => {
                console.log(object.userid);
                this.setState({
                  showProfile: [...this.state.showProfile, object]
                });
              });
            })
            .catch(err => {
              console.log(err);
            });
        });
      })
      .catch(err => {
        console.log(err);
      });

    // axios
    //   .get(`http://localhost:6002/api/users/registeredUsers/${id}`)
    //   .then(user => {
    //     this.setState({
    //       name: user.data[0].name
    //     });
    //   })
    //   .catch(err => {
    //     console.log(err);
    //   });
    // this.state.showUserID.map((object, i) => {
    //   axios
    //     .get(`http://localhost:6002/api/profile/${object}`)
    //     .then(res => {
    //       console.log("Here" + res.data);
    //     })
    //     .catch(err => {
    //       console.log(err);
    //     });
    // });
  }

  sendingRequest(friendID) {
    console.log(friendID);
    let id = localStorage.getItem("userid");
    axios
      .post(`http://localhost:6002/api/friend/sendrequest/${id}/${friendID}`)
      .then(user => {
        alert("Request has been sent");
        window.location.reload(); 
      })
      .catch(err => {
        console.log(err);
      });
  }

  render() {
    return (
      <div>
        <Navigation />
         
        {this.state.showProfile
          ? this.state.showProfile.length > 0
            ? this.state.showProfile.map((object, i) => {
                return (
                  <div className="row">
                    <div className="col-lg-4">
                      <br />
                      <br />
                      <div className="card" style={{ display: "inlineBlock" }}>
                        <img
                          className="card-img-top"
                          src={require("../../../assets/profile.png")}
                          width="40px"
                          height="200px"
                          alt="Card image"
                        />
                        <div className="card-body">
                          <h4 className="card-title">@{object.handle}</h4>
                          <p className="card-text">{object.bio}</p>;
                          <button
                            onClick={() => this.sendingRequest(object.userid)}
                            className="btn btn-primary"
                          >
                            Connect
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>
                );
              })
            : null
          : null} 
      </div>
    );
  }
}

export default Network;
