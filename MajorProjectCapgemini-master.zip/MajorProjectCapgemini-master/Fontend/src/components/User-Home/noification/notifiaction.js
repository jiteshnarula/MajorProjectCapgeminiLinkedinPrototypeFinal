import React, { Component } from "react";
import Navigation from "../Navigation-Component/navigation";
import axios from "axios";

class Notification extends Component {
  constructor(props) {
    super(props);
    this.state = {
      friendlist: "",
      totalUserid: [],
      requestNotifications: [],
      requestedNotifications: []
    };
  }
  componentDidMount() {
    axios
      .get(
        `http://localhost:6002/api/friend/gettingfriends/${localStorage.getItem(
          "userid"
        )}`
      )
      .then(res => {
        this.setState({
          friendlist: res.data
        });

        this.state.friendlist.map((object, i) => {
          object.requestList.map((object, i) => {
            axios
              .get(
                `http://localhost:6002/api/users/registeredUsers/${
                  object.userid
                }`
              )
              .then(user => {
                console.log(user.data);
                user.data.map((object, i) => {
                  this.setState({
                    requestNotifications: [
                      ...this.state.requestNotifications,
                      object.name
                    ]
                  });
                  console.log(this.state.requestNotifications);
                });
              })
              .catch(err => {
                console.log(err);
              });
          });
          object.requestedList.map((object, i) => {
            axios
              .get(
                `http://localhost:6002/api/users/registeredUsers/${
                  object.userid
                }`
              )
              .then(user => {
                console.log(user.data);
                user.data.map((object, i) => {
                  this.setState({
                    requestedNotifications: [
                      ...this.state.requestedNotifications,
                      object
                    ]
                  });

                  console.log(this.state.requestedNotifications);
                });
              })
              .catch(err => {
                console.log(err);
              });
          });
        });

        // console.log(this.state.friendlist);
      })
      .catch(err => {
        console.log(err);
      });
  }
  acceptRequest(friendid) {
    console.log(friendid);
    let id = localStorage.getItem("userid");
    axios
      .delete(
        `http://localhost:6002/api/friend/acceptrequest/${id}/${friendid}`
      )
      .then(user => {
        alert("You both are friends now :)");
        window.location.reload();
      })
      .catch(err => {
        console.log(err);
      });
  }

  render() {
    return (
      <div> 
        <Navigation/>
        {this.state.requestNotifications
          ? this.state.requestNotifications.map((object, i) => {
              return (
                <div className="container">
                  <div className="card" style={{ display: "inlineBlock" }}>
                    <div className="card-body">
                      <h1>
                        You have send the friend request to {object}
                        <h1 />
                      </h1>
                    </div>
                  </div>
                </div>
              );
            })
          : null}
        {this.state.requestedNotifications
          ? this.state.requestedNotifications.map((object, i) => {
              return (
                <div className="container">
                  <div className="card" style={{ display: "inlineBlock" }}>
                    <div className="card-body">
                      <h3>
                        You have received the friend request from {object.name}
                    
                        <button
                          className="btn btn-primary"
                          onClick={() => this.acceptRequest(object._id)}
                        >
                          Accept
                        </button>
                      </h3>
                    </div>
                  </div>
                </div>
              );
            })
          : null}
      </div>
    );
  }
}

export default Notification;
