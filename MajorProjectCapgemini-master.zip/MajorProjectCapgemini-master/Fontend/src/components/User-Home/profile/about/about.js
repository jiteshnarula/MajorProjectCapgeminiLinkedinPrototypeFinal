import React, { Component } from "react";
import axios from "axios";
import { Link } from "react-router-dom";

const initialState = {
  handle: "",
  website: "",
  location: "",
  bio: "",
  skills: "",
  // userimage: "",
  handleError: "",
  websiteError: "",
  locationError: "",
  bioError: "",
  skillsError: ""
  // userimageError: ""
};

class About extends Component {
  constructor(props) {
    super(props);
    // this.routeChangeHome = this.routeChangeHome.bind(this);
    this.state = initialState;
    this.onSubmit = this.onSubmit.bind(this);
    this.onChange = this.onChange.bind(this);
  }

  onChange(e) {
    this.setState({ [e.target.name]: [e.target.value] });
  }

  validate = () => {
    let handleError = "";
    let websiteError = "";
    let locationError = "";
    let bioError = "";
    let skillsError = "";
    // let userimageError = "";

    if (!this.state.handle) {
      handleError = "Handle Cannot be blank";
    }

    if (!this.state.website) {
      websiteError = "Website Cannot be blank";
    }

    if (!this.state.location) {
      locationError = "Location Cannot be blank";
    }

    if (!this.state.bio) {
      bioError = "Bio Cannot be blank";
    }

    if (!this.state.skills) {
      skillsError = "Skills Cannot be blank";
    }
    // if (!this.state.userimage) {
    //   userimageError = "Userimage cannot be blank";
    // }

    if (
      websiteError ||
      locationError ||
      handleError ||
      bioError ||
      skillsError
      // userimageError ||
    ) {
      this.setState({
        websiteError,
        locationError,
        handleError,
        // userimageError,
        bioError,
        skillsError
      });
      return false;
    }

    return true;
  };

  onSubmit(e) {
    e.preventDefault();

    var valueObject = {
      handle: this.state.handle,
      website: this.state.website,
      location: this.state.location,
      bio: this.state.bio,
      skills: this.state.skills
      // userimage: fd
    };
    // console.log(valueObject);
    const isValid = this.validate();
    if (isValid) {
      console.log(valueObject);
      axios
        .post(
          `http://localhost:6002/api/profile/${localStorage.getItem("userid")}`,
          valueObject
        )
        .then(res => {
          console.log(res.data);

          this.setState(initialState);

          alert("Details successfully added");

          this.props.history.push("/profile");
        })
        .catch(err => {
          if (err.response.data.status === 0) {
            alert("Handle already exist please choose something else");
          } else {
            alert("Not able to connect to the server");
          }
          console.log(err.response.data);
        });

      // routeChangeHome() {
      //   let path = "/home";
      //   this.props.history.push(path);
      // }
      // routeChangeLogin() {}
    }
  }
  render() {
    return (
      <div style={{ backgroundColor: "brown" }}>
        <br />
        <br />
        <div className="row justify-content-lg-center">
          <div className="col-lg-5">
            <div className="card">
              <div className="card-body">
                <center>
                  {/* <img src={images} width="140px" height="100px" /> */}
                </center>
                <h3 align="center">Enter Details About Yourself</h3>
                <br />
                <form align="center" onSubmit={this.onSubmit}>
                  <div className="row justify-content-lg-center">
                    <div className="col-lg-8">
                      <div className="form-group">
                        <input
                          type="text"
                          className="form-control text-center"
                          placeholder="Enter Handle"
                          value={this.state.handle}
                          name="handle"
                          onChange={this.onChange}
                        />
                      </div>
                    </div>
                  </div>
                  {this.state.handleError ? (
                    <div className="alert alert-danger" role="alert">
                      {this.state.handleError}
                    </div>
                  ) : null}
                  <div className=" row justify-content-lg-center">
                    <div className="col-lg-8">
                      <div className="form-group">
                        <input
                          type="text"
                          className="form-control text-center"
                          placeholder="Enter Website"
                          name="website"
                          value={this.state.website}
                          onChange={this.onChange}
                        />
                      </div>
                    </div>
                  </div>
                  {this.state.websiteError ? (
                    <div className="alert alert-danger" role="alert">
                      {this.state.websiteError}
                    </div>
                  ) : null}
                  <div className="row justify-content-lg-center">
                    <div className="col-lg-8">
                      <div className="form-group">
                        <input
                          type="text"
                          className="form-control text-center"
                          name="location"
                          placeholder="Enter Location"
                          value={this.state.location}
                          onChange={this.onChange}
                        />
                      </div>
                    </div>
                  </div>
                  {this.state.locationError ? (
                    <div className="alert alert-danger" role="alert">
                      {this.state.locationError}
                    </div>
                  ) : null}
                  <div className="row justify-content-lg-center">
                    <div className="col-lg-8">
                      <div className="form-group">
                        <textarea
                          className="form-control text-center"
                          name="bio"
                          value={this.state.bio}
                          placeholder="Enter Bio"
                          onChange={this.onChange}
                        />
                      </div>
                    </div>
                  </div>
                  {this.state.bioError ? (
                    <div className="alert alert-danger">
                      {this.state.bioError}
                    </div>
                  ) : null}
                  <div className="row justify-content-lg-center">
                    <div className="col-lg-8">
                      <div className="form-group">
                        <input
                          type="text"
                          className="form-control text-center"
                          name="skills"
                          placeholder="Enter Skills"
                          value={this.state.skills}
                          onChange={this.onChange}
                        />
                        <span style={{ fontSize: "10px", color: "red" }}>
                          you can add multiple skills by seprating comma
                        </span>
                      </div>
                    </div>
                  </div>
                  {this.state.skillsError ? (
                    <div className="alert alert-danger" role="alert">
                      {this.state.skillsError}
                    </div>
                  ) : null}
                  {/* <div align="center">
                   <input
                    type="file"
                    className=" text-center"
                    name="userimage"
                    value={this.state.userimage}
                    onChange={this.onChange}
                  />
                </div>
                {this.state.userimageError ? (
                  <div className="alert alert-danger">
                    {this.state.userimageError}
                  </div>
                ) : null} */}
                  <br />
                  <input
                    type="submit"
                    value="Sign in"
                    className="btn btn-primary"
                  />
                  &nbsp;
                  <Link to="/" className="btn btn-success">
                    Cancel
                  </Link>
                </form>
              </div>
            </div>
          </div>
        </div>
        <br />
        <br />
      </div>
    );
  }
}

export default About;
