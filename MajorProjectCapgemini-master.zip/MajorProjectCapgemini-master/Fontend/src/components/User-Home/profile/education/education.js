import React, { Component } from "react";
import axios from "axios";
import { Link } from "react-router-dom";

const initialState = {
  sscschoolname: "",
  sscpassingoutyear: "",
  sscpercentage: "",
  hscschoolname: "",
  hscpassingoutyear: "",
  hscpercentage: "",
  collegename: "",
  stream: "",
  passingoutyear: "",
  percentage: "",
  // userimage: "",
  sscschoolnameError: "",
  sscpassingoutyearError: "",
  sscpercentageError: "",
  hscschoolnameError: "",
  hscpassingoutyearError: "",
  hscpercentageError: "",
  collegenameError: "",
  streamError: "",
  passingoutyearError: "",
  percentageError: ""
  // userimageError: ""
};

class Education extends Component {
  constructor(props) {
    super(props);
    // this.routeChangeHome = this.routeChangeHome.bind(this);
    this.state = initialState;
    this.onSubmit = this.onSubmit.bind(this);
    this.onChange = this.onChange.bind(this);
  }

  onChange(e) {
    this.setState({ [e.target.name]: [e.target.value] });
  }

  validate = () => {
    let sscschoolnameError = "";
    let sscpassingoutyearError = "";
    let sscpercentageError = "";
    let hscschoolnameError = "";
    let hscpassingoutyearError = "";
    let hscpercentageError = "";
    let collegenameError = "";
    let streamError = "";
    let passingoutyearError = "";
    let percentageError = "";
    // let userimageError = "";

    if (!this.state.sscschoolname) {
      sscschoolnameError = "School Name cannot be blank";
    }

    if (!this.state.hscschoolname) {
      hscschoolnameError = "School Name cannot be blank";
    }
    if (!this.state.collegename) {
      collegenameError = "College name cannot be blank";
    }
    if (!this.state.stream) {
      streamError = "Stream cannot be blank";
    }

    if (!this.state.sscpassingoutyear) {
      sscpassingoutyearError = "Passing out year cannot be blank";
    }

    if (!this.state.hscpassingoutyear) {
      hscpassingoutyearError = "Passing out year cannot be blank";
    }
    if (!this.state.passingoutyear) {
      passingoutyearError = "Passing out year cannot be blank";
    }
    if (!this.state.percentage) {
      percentageError = "Percentage cannot be blank";
    }

    if (!this.state.hscpercentage) {
      hscpercentageError = "Percentage cannot be blank";
    }
    if (!this.state.sscpercentage) {
      sscpercentageError = "Percentage cannot be blank";
    }

    // if (!this.state.userimage) {
    //   userimageError = "Userimage cannot be blank";
    // }

    if (
      sscschoolnameError ||
      sscpassingoutyearError ||
      sscpercentageError ||
      hscschoolnameError ||
      hscpassingoutyearError ||
      hscpercentageError ||
      collegenameError ||
      streamError ||
      passingoutyearError ||
      percentageError
      // userimageError ||
    ) {
      this.setState({
        sscschoolnameError,
        sscpassingoutyearError,
        sscpercentageError,
        hscschoolnameError,
        hscpassingoutyearError,
        hscpercentageError,
        collegenameError,
        streamError,
        passingoutyearError,
        percentageError
      });
      return false;
    }

    return true;
  };

  onSubmit(e) {
    e.preventDefault();

    var valueObject = {
      sscschoolname: this.state.sscschoolname,
      sscpassingoutyear: this.state.sscpassingoutyear,
      sscpercentage: this.state.sscpercentage,
      hscschoolname: this.state.hscschoolname,
      hscpassingoutyear: this.state.hscpassingoutyear,
      hscpercentage: this.state.hscpercentage,
      collegename: this.state.collegename,
      stream: this.state.stream,
      passingoutyear: this.state.passingoutyear,
      percentage: this.state.percentage
      // userimage: fd
    };
    // console.log(valueObject);
    const isValid = this.validate();
    if (isValid) {
      console.log(valueObject);
      axios
        .post(
          `http://localhost:6002/api/profile/education/${localStorage.getItem(
            "userid"
          )}`,
          valueObject
        )
        //${localStorage.getItem("userid")
        .then(res => {
          console.log(res.data);

          this.setState(initialState);

          alert("Education Details successfully added");

          this.props.history.push("/profile");
        })
        .catch(err => {
          alert("Not able to connect to the server");
          console.log(err.response.data);
        });
    }
  }
  render() {
    return (
      <div style={{ backgroundColor: "brown" }}>
        <br />
        <br />
        <div className="row justify-content-lg-center">
          <div className="col-lg-5">
            <div className="card">
              <div className="card-body">
                <center>
                  {/* <img src={images} width="140px" height="100px" /> */}
                </center>
                <h3 align="center">Enter Education Details</h3>
                <br />
                <form align="center" onSubmit={this.onSubmit}>
                  <div className="row justify-content-lg-center">
                    <div className="col-lg-8">
                      <div className="form-group">
                        <h3 className="text-center"> Enter SSC Details</h3>
                        <input
                          type="text"
                          className="form-control text-center"
                          placeholder="Enter School Name"
                          value={this.state.sscschoolname}
                          name="sscschoolname"
                          onChange={this.onChange}
                        />
                      </div>
                    </div>
                  </div>
                  {this.state.sscschoolnameError ? (
                    <div className="alert alert-danger" role="alert">
                      {this.state.sscschoolnameError}
                    </div>
                  ) : null}
                  <div className=" row justify-content-lg-center">
                    <div className="col-lg-8">
                      <div className="form-group">
                        <input
                          type="text"
                          className="form-control text-center"
                          placeholder="Enter Passed Out Year"
                          name="sscpassingoutyear"
                          value={this.state.sscpassingoutyear}
                          onChange={this.onChange}
                        />
                      </div>
                    </div>
                  </div>
                  {this.state.sscpassingoutyearError ? (
                    <div className="alert alert-danger" role="alert">
                      {this.state.sscpassingoutyearError}
                    </div>
                  ) : null}
                  <div className="row justify-content-lg-center">
                    <div className="col-lg-8">
                      <div className="form-group">
                        <input
                          type="text"
                          className="form-control text-center"
                          name="sscpercentage"
                          placeholder="Enter Percentage"
                          value={this.state.sscpercentage}
                          onChange={this.onChange}
                        />
                      </div>
                    </div>
                  </div>
                  {this.state.sscpercentageError ? (
                    <div className="alert alert-danger" role="alert">
                      {this.state.sscpercentageError}
                    </div>
                  ) : null}
                  <div className="row justify-content-lg-center">
                    <div className="col-lg-8">
                      <div className="form-group">
                        <input
                          type="text"
                          className="form-control text-center"
                          name="hscschoolname"
                          placeholder="Enter school name"
                          value={this.state.hscschoolname}
                          onChange={this.onChange}
                        />
                      </div>
                    </div>
                  </div>
                  {this.state.hscschoolnameError ? (
                    <div className="alert alert-danger" role="alert">
                      {this.state.hscschoolnameError}
                    </div>
                  ) : null}
                  <div className="row justify-content-lg-center">
                    <div className="col-lg-8">
                      <div className="form-group">
                        <h3 className="text-center"> Enter HSC Details</h3>
                        <input
                          type="text"
                          className="form-control text-center"
                          placeholder="Enter School Name"
                          value={this.state.hscschoolname}
                          name="hscschoolname"
                          onChange={this.onChange}
                        />
                      </div>
                    </div>
                  </div>
                  {this.state.hscschoolnameError ? (
                    <div className="alert alert-danger" role="alert">
                      {this.state.hscschoolnameError}
                    </div>
                  ) : null}
                  <div className=" row justify-content-lg-center">
                    <div className="col-lg-8">
                      <div className="form-group">
                        <input
                          type="text"
                          className="form-control text-center"
                          placeholder="Enter Passed Out Year"
                          name="hscpassingoutyear"
                          value={this.state.hscpassingoutyear}
                          onChange={this.onChange}
                        />
                      </div>
                    </div>
                  </div>
                  {this.state.hscpassingoutyearError ? (
                    <div className="alert alert-danger" role="alert">
                      {this.state.hscpassingoutyearError}
                    </div>
                  ) : null}
                  <div className="row justify-content-lg-center">
                    <div className="col-lg-8">
                      <div className="form-group">
                        <input
                          type="text"
                          className="form-control text-center"
                          name="hscpercentage"
                          placeholder="Enter Percentage"
                          value={this.state.hscpercentage}
                          onChange={this.onChange}
                        />
                      </div>
                    </div>
                  </div>
                  {this.state.hscpercentageError ? (
                    <div className="alert alert-danger" role="alert">
                      {this.state.hscpercentageError}
                    </div>
                  ) : null}
                  <div className="row justify-content-lg-center">
                    <div className="col-lg-8">
                      <div className="form-group">
                        <h3 className="text-center">
                          {" "}
                          Enter Graduation Details
                        </h3>
                        <input
                          type="text"
                          className="form-control text-center"
                          placeholder="Enter College Name"
                          value={this.state.collegename}
                          name="collegename"
                          onChange={this.onChange}
                        />
                      </div>
                    </div>
                  </div>
                  {this.state.collegenameError ? (
                    <div className="alert alert-danger" role="alert">
                      {this.state.collegenameError}
                    </div>
                  ) : null}
                  <div className=" row justify-content-lg-center">
                    <div className="col-lg-8">
                      <div className="form-group">
                        <input
                          type="text"
                          className="form-control text-center"
                          placeholder="Enter Stream"
                          name="stream"
                          value={this.state.stream}
                          onChange={this.onChange}
                        />
                      </div>
                    </div>
                  </div>
                  {this.state.streamError ? (
                    <div className="alert alert-danger" role="alert">
                      {this.state.streamError}
                    </div>
                  ) : null}
                  <div className="row justify-content-lg-center">
                    <div className="col-lg-8">
                      <div className="form-group">
                        <input
                          type="text"
                          className="form-control text-center"
                          name="passingoutyear"
                          placeholder="Enter Passing Out Year"
                          value={this.state.passingoutyear}
                          onChange={this.onChange}
                        />
                      </div>
                    </div>
                  </div>
                  {this.state.passingoutyearError ? (
                    <div className="alert alert-danger" role="alert">
                      {this.state.passingoutyearError}
                    </div>
                  ) : null}
                  <div className="row justify-content-lg-center">
                    <div className="col-lg-8">
                      <div className="form-group">
                        <input
                          type="number"
                          className="form-control text-center"
                          name="percentage"
                          placeholder="Enter Percentage"
                          value={this.state.percentage}
                          onChange={this.onChange}
                        />
                      </div>
                    </div>
                  </div>
                  {this.state.percentageError ? (
                    <div className="alert alert-danger" role="alert">
                      {this.state.percentageError}
                    </div>
                  ) : null}
                  {/* <div align="center">
                   <input
                    type="file"
                    className=" text-center"
                    name="userimage"
                    value={this.state.userimage}
                    onChange={this.onChange}
                  />
                </div>
                {this.state.userimageError ? (
                  <div className="alert alert-danger">
                    {this.state.userimageError}
                  </div>
                ) : null} */}
                  <br />
                  <input
                    type="submit"
                    value="Sign in"
                    className="btn btn-primary"
                  />
                  &nbsp;
                  <Link to="/" className="btn btn-success">
                    Cancel
                  </Link>
                </form>
              </div>
            </div>
          </div>
        </div>
        <br />
        <br />
      </div>
    );
  }
}

export default Education;
