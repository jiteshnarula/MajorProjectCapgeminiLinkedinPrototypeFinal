import React, { Component } from "react";
import axios from "axios";
import { Link } from "react-router-dom";

const initialState = {
  position: "",
  companyname: "",
  location: "",
  yearsofexperience: "",

  // userimage: "",
  positionError: "",
  companynameError: "",
  locationError: "",
  yearsofexperienceError: ""
  // userimageError: ""
};

class Experience extends Component {
  constructor(props) {
    super(props);
    // this.routeChangeHome = this.routeChangeHome.bind(this);
    this.state = initialState;
    this.onSubmit = this.onSubmit.bind(this);
    this.onChange = this.onChange.bind(this);
  }

  onChange(e) {
    this.setState({ [e.target.name]: [e.target.value] });
  }

  validate = () => {
    let positionError = "";
    let locationError = "";
    let companynameError = "";
    let yearsofexperienceError = "";

    // let userimageError = "";

    if (!this.state.position) {
      positionError = "Position Cannot be blank";
    }

    if (!this.state.location) {
      locationError = "Location Cannot be blank";
    }

    if (!this.state.companyname) {
      companynameError = "Company Name Cannot be blank";
    }

    if (!this.state.yearsofexperience) {
      yearsofexperienceError = "Years of Experience Cannot be blank";
    }

    // if (!this.state.userimage) {
    //   userimageError = "Userimage cannot be blank";
    // }

    if (
      positionError ||
      locationError ||
      companynameError ||
      yearsofexperienceError
      // userimageError ||
    ) {
      this.setState({
        positionError,
        locationError,
        companynameError,
        // userimageError,
        yearsofexperienceError
      });
      return false;
    }

    return true;
  };

  onSubmit(e) {
    e.preventDefault();

    var valueObject = {
      position: this.state.position.toString(),
      location: this.state.location.toString(),
      companyname: this.state.companyname.toString(),
      yearsofexperience: this.state.yearsofexperience.toString()
      // userimage: fd
    };
    // console.log(valueObject);
    const isValid = this.validate();
    if (isValid) {
      console.log(valueObject);
      axios
        .post(
          `http://localhost:6002/api/profile/experience/${localStorage.getItem(
            "userid"
          )}`,
          valueObject
        )
        //${localStorage.getItem("userid")
        .then(res => {
          console.log(res.data);

          this.setState(initialState);

          alert("Experience Details successfully added");

          this.props.history.push("/profile");
        })
        .catch(err => {
          alert("Not able to connect to the server");
          console.log(err.response.data);
        });
    }
  }
  render() {
    return (
      <div style={{ backgroundColor: "brown" }}>
        <br />
        <br />
        <div className="row justify-content-lg-center">
          <div className="col-lg-5">
            <div className="card">
              <div className="card-body">
                <center>
                  {/* <img src={images} width="140px" height="100px" /> */}
                </center>
                <h3 align="center">Enter Experience Details</h3>
                <br />
                <form align="center" onSubmit={this.onSubmit}>
                  <div className="row justify-content-lg-center">
                    <div className="col-lg-8">
                      <div className="form-group">
                        <input
                          type="text"
                          className="form-control text-center"
                          placeholder="Enter Company Name"
                          value={this.state.companyname}
                          name="companyname"
                          onChange={this.onChange}
                        />
                      </div>
                    </div>
                  </div>
                  {this.state.companynameError ? (
                    <div className="alert alert-danger" role="alert">
                      {this.state.companynameError}
                    </div>
                  ) : null}
                  <div className=" row justify-content-lg-center">
                    <div className="col-lg-8">
                      <div className="form-group">
                        <input
                          type="text"
                          className="form-control text-center"
                          placeholder="Enter Position"
                          name="position"
                          value={this.state.position}
                          onChange={this.onChange}
                        />
                      </div>
                    </div>
                  </div>
                  {this.state.positionError ? (
                    <div className="alert alert-danger" role="alert">
                      {this.state.positionError}
                    </div>
                  ) : null}
                  <div className="row justify-content-lg-center">
                    <div className="col-lg-8">
                      <div className="form-group">
                        <input
                          type="text"
                          className="form-control text-center"
                          name="location"
                          placeholder="Enter Location"
                          value={this.state.location}
                          onChange={this.onChange}
                        />
                      </div>
                    </div>
                  </div>
                  {this.state.locationError ? (
                    <div className="alert alert-danger" role="alert">
                      {this.state.locationError}
                    </div>
                  ) : null}
                  <div className="row justify-content-lg-center">
                    <div className="col-lg-8">
                      <div className="form-group">
                        <input
                          type="number"
                          className="form-control text-center"
                          name="yearsofexperience"
                          placeholder="Enter Experience"
                          value={this.state.yearsofexperience}
                          onChange={this.onChange}
                        />
                      </div>
                    </div>
                  </div>
                  {this.state.yearsofexperienceError ? (
                    <div className="alert alert-danger" role="alert">
                      {this.state.yearsofexperienceError}
                    </div>
                  ) : null}
                  {/* <div align="center">
                   <input
                    type="file"
                    className=" text-center"
                    name="userimage"
                    value={this.state.userimage}
                    onChange={this.onChange}
                  />
                </div>
                {this.state.userimageError ? (
                  <div className="alert alert-danger">
                    {this.state.userimageError}
                  </div>
                ) : null} */}
                  <br />
                  <input
                    type="submit"
                    value="Sign in"
                    className="btn btn-primary"
                  />
                  &nbsp;
                  <Link to="/" className="btn btn-success">
                    Cancel
                  </Link>
                </form>
              </div>
            </div>
          </div>
        </div>
        <br />
        <br />
      </div>
    );
  }
}

export default Experience;
