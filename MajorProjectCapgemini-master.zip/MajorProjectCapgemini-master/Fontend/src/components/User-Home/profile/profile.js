import React, { Component } from "react";
import Navigation from "../Navigation-Component/navigation";
import { Link } from "react-router-dom";
import axios from "axios";

const initialState = {
  profile: "",
  bio: "",
  handle: "",
  website: "",
  skills: [],
  ssc: "",
  graduation: "",
  hsc: "",
  exp: "",
  gettingName: "",
  name: "",
  checkexp: ""
};

class Profile extends Component {
  constructor(props) {
    super(props);
    this.state = { initialState };
  }
  componentDidMount() {
    var id = localStorage.getItem("userid");
    axios
      .get(`http://localhost:6002/api/profile/${id}`)
      .then(res => {
        console.log(res.data.experience[0]);
        this.setState({
          skills: res.data.skills,
          bio: res.data.bio,
          handle: res.data.handle,
          website: res.data.website
        });
        this.setState({
          checkexp: res.data.experience[0]
        });
        this.setState({
          exp: res.data.experience
        });
        this.setState({
          profile: res.data,
          ssc: res.data.education[0].ssc,
          hsc: res.data.education[0].hsc,
          graduation: res.data.education[0].graduation
        });
        // console.log(res.data.bio);
        // console.log(this.state.ssc);
        // console.log(this.state.exp);
      })
      .catch(err => {
        console.log(err);
      });

    axios
      .get(`http://localhost:6002/api/users/registeredUsers/${id}`)
      .then(user => {
        this.setState({
          name: user.data[0].name
        });
      })
      .catch(err => {
        console.log(err);
      });
  }
  render() {
    // console.log(this.state.bio);

    if (this.state.profile) {
      console.log(this.state.profile);
    }

    console.log(this.state.skills);
    console.log(this.state.ssc);
    console.log(this.state.exp);

    return (
      <div>
        <Navigation />
        <div>
          <div className="col-md-12 col-sm-12 col-xs-12 col-lg-12">
            <img
              className="img"
              height="200px"
              width="100%"
              src={require("../../../assets/stars.jpg")}
            />
          </div>

          <div className="row">
            {/* <div className="col-md-12 col-md-12-sm-12 col-xs-12 col-lg-12" style={{left: '110px' }}>
                                    <div><FontAwesomeIcon icon="envelope" /></div>
                                </div> */}

            <div
              className="col-md-12 col-md-12-sm-12 col-xs-12 col-lg-12 text-center"
              style={{ top: "-90px" }}
            >
              <img
                src={require("../../../assets/img.png")}
                width="300px"
                height="250px"
              />

              <h4>{this.state.name}</h4>
            </div>
            <div className="container">
              <div className="row">
                <div className="col-lg-3"> </div>

                {this.state.skills === undefined ? (
                  <div className="col-lg-2">
                    <Link className="btn btn-primary" to="/about">
                      Add About Yourself
                    </Link>
                  </div>
                ) : null}

                {this.state.ssc === undefined ? (
                  <div className="col-lg-2">
                    <Link className="btn btn-primary" to="/education">
                      Add Education Details
                    </Link>
                  </div>
                ) : null}

                {this.state.checkexp === undefined ? (
                  <div className="col-lg-2">
                    <Link className="btn btn-primary" to="/exp">
                      Add Experience Details
                    </Link>
                  </div>
                ) : null}
              </div>
            </div>
          </div>

          <div className="container">
            {" "}
            {this.state.skills ? (
              this.state.skills.length !== 0 ? (
                <div className="card">
                  <div className="row">
                    <div className="col-lg-12">
                      <div>
                        <h4 className="text-center">BIO</h4>
                        <h5>{this.state.bio}</h5>

                        <div className="row">
                          <div className="col-lg-2" />
                          <div className="col-lg-3">
                            <h4>Handle</h4>
                            <h5>@{this.state.handle}</h5>
                          </div>

                          <div className="col-lg-3">
                            <h4>Website</h4>
                            <h5>{this.state.website}</h5>
                          </div>

                          <div className="col-lg-3">
                            <h4>Skills</h4>

                            {this.state.skills
                              ? this.state.skills.map((object, i) => (
                                  <ul key={i}>
                                    <li> {object}</li>
                                  </ul>
                                ))
                              : null}
                          </div>
                          {/* {console.log(this.state.skills)} */}
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              ) : null
            ) : null}
            <div className="row">
              {this.state.ssc ? (
                this.state.ssc.length !== 0 ? (
                  <div className="col-lg-8">
                    <div className="card">
                      <div>
                        <h1> SSC Details</h1>

                        <table className="table">
                          <thead>
                            <tr>
                              <th>School Name </th>
                              <th>Passed Out: </th>
                              <th>Percentage</th>
                            </tr>
                          </thead>
                          <tbody>
                            {this.state.ssc
                              ? this.state.ssc.map((object, i) => (
                                  <tr key={i}>
                                    <td> {object.schoolName}</td>
                                    <td> {object.passingOutYear}</td>
                                    <td> {object.percentage}</td>
                                  </tr>
                                ))
                              : null}
                          </tbody>
                        </table>

                        <h1> HSC Details</h1>

                        <table className="table">
                          <thead>
                            <tr>
                              <th>School Name </th>
                              <th>Passed Out: </th>
                              <th>Percentage</th>
                            </tr>
                          </thead>
                          <tbody>
                            {this.state.hsc
                              ? this.state.hsc.map((object, i) => (
                                  <tr key={i}>
                                    <td> {object.schoolName}</td>
                                    <td> {object.passingOutYear}</td>
                                    <td> {object.percentage}</td>
                                  </tr>
                                ))
                              : null}
                          </tbody>
                        </table>

                        <h1> Graduation Details</h1>

                        <table className="table">
                          <thead>
                            <tr>
                              <th>College Name </th>
                              <th>Passing Out: </th>
                              <th>Percentage</th>
                              <th>Stream</th>
                            </tr>
                          </thead>
                          <tbody>
                            {this.state.graduation
                              ? this.state.graduation.map((object, i) => (
                                  <tr key={i}>
                                    <td> {object.collegeName}</td>
                                    <td> {object.passingOutYear}</td>
                                    <td> {object.percentage}</td>
                                    <td> {object.stream}</td>
                                  </tr>
                                ))
                              : null}
                          </tbody>
                        </table>
                      </div>
                    </div>
                  </div>
                ) : null
              ) : null}

              {this.state.exp ? (
                this.state.exp.length !== 0 ? (
                  <div className="col-lg-4">
                    <div className="card">
                      <div>
                        <h1> Experience</h1>
                        <table className="table">
                          <thead>
                            <tr>
                              <th>Company Name </th>
                              <th>Location</th>
                              <th>Position</th>
                              <th>YOE</th>
                            </tr>
                          </thead>
                          <tbody>
                            {this.state.exp
                              ? this.state.exp.map((object, i) => (
                                  <tr key={i}>
                                    <td> {object.companyname}</td>
                                    <td> {object.location}</td>
                                    <td> {object.position}</td>
                                    <td> {object.yearsofexperience}</td>
                                  </tr>
                                ))
                              : null}
                          </tbody>
                        </table>
                      </div>
                    </div>
                  </div>
                ) : null
              ) : null}
            </div>
          </div>
        </div>
      </div>
    );
  }
}

export default Profile;
