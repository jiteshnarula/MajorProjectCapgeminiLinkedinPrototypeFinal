import React, { Component } from "react";
import { Link } from "react-router-dom";
import axios from "axios";

const initialState = {
  email: "",
  password: "",
  emailError: "",
  passwordError: ""
};

class Login extends React.Component {
  constructor(props) {
    super(props);
    this.state = initialState;
    this.onChange = this.onChange.bind(this);
    this.onSubmit = this.onSubmit.bind(this);
  }

  routeChangeGet() {
    let path = "/signup";
    this.props.history.push(path);
  }

  onChange(e) {
    this.setState({
      [e.target.name]: [e.target.value]
    });
  }

  onSubmit(e) {
    e.preventDefault();
    var valueObject = {
      email: this.state.email,
      password: this.state.password
    };
    const isValid = this.validate();
    if (isValid) {
      console.log(valueObject);

      axios
        .get(
          `http://localhost:6002/api/users/gettingresgisteredusers/${
            valueObject.email
          }`
        )
        .then(res => {
          console.log(res.data);
          res.data.map((object, i) => {
            console.log(object);
            console.log("before" + localStorage.getItem("userid"));
            localStorage.setItem("userid", object._id);
            console.log("after" + localStorage.getItem("userid"));
          });
        })
        .catch(err => {
          console.log(err);
        });

      axios
        .post("http://localhost:6002/api/users/login", valueObject)
        .then(res => {
          console.log(res.data);
          if (res.data.status === 200) {
            alert("Login successfully");
            localStorage.setItem("emailid", valueObject.email);
            this.props.history.push("/home");
            this.setState(initialState);
          } else if (res.data.status === 0) {
            alert(res.data.email);
          }
        })
        .catch(err => {
          if (err.response.data.status === 1) {
            alert(err.response.data.password);
          } else {
            alert("Not able to connect to the server");
          }
          console.log(err.response.data);
        });
      this.setState(initialState);
    }
  }

  validate = () => {
    let emailError = "";
    var passwordError = "";

    var re = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
    console.log(re.test(String(this.state.email).toLowerCase()));

    if (!re.test(String(this.state.email).toLowerCase())) {
      emailError = "Invalid Email";
    }
    console.log("password state" + this.state.password);
    if (!this.state.password) {
      passwordError = "Password Cannot be blank";
      console.log("password error value" + passwordError);
    }

    if (emailError || passwordError) {
      this.setState({
        emailError,
        passwordError
      });
      return false;
    }

    return true;
  };

  render() {
    return (
      <div style={{ backgroundColor: "brown" }}>
        <br />
        <br /> <br /> <br /> <br /> 

        <div className="row justify-content-md-center">
          <div className="col-md-5 col-xs-5">
            <div className="card">
              <div className="row justify-content-md-center">
                <center>
                  {/* <img
                      src={image}
                      align="center"
                      width="140px"
                      height="100px"
                    /> */}
                  <h1 className="card-title" className="margin-top-30">
                    Login Here
                  </h1>
                  <br />
                  <form onSubmit={this.onSubmit}>
                    {/* <label align="left">Email:</label> */}
                    <input
                      type="email"
                      ref="email"
                      placeholder="Enter Email"
                      className="form-control text-center"
                      name="email"
                      value={this.state.email}
                      onChange={this.onChange}
                    />
                    {this.state.emailError ? (
                      <div className="alert alert-danger" role="alert">
                        {this.state.emailError}
                      </div>
                    ) : null}
                    <br />
                    {/* <label>Password:</label> */}
                    <div className="form-group">
                      <input
                        type="password"
                        className="form-control text-center"
                        name="password"
                        value={this.state.password}
                        placeholder="Enter Password"
                        onChange={this.onChange}
                        
                      />
                    </div>
                    {this.state.passwordError ? (
                      <div className="alert alert-danger">
                        {this.state.passwordError}
                      </div>
                    ) : null}
                   
                    <button className="btn btn-primary margin-bottom-10">
                      Login
                    </button>
                    &nbsp;&nbsp;&nbsp;
                    {/* <button className="btn btn-warning margin-bottom-10">
                      Forgot Password ?
                    </button> */}
                    <br />
                    <br />
                    Not a user?{" "}
                    <Link className="btn btn-link" to="/register">
                      Sign up!
                    </Link>
                  
                    
                  </form>
                  
                </center>
              </div>
            </div>
          </div>
        </div>
        <br />
        <br />
        <br /> <br /> <br /> <br /> <br /> <br /> <br /> <br /> <br />  <br /><br /> <br /> <br />
      </div>
    );
  }
}

export default Login;
