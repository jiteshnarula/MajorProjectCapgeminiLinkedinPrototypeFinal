import React, { Component } from "react";
import axios from "axios";
import { Link } from "react-router-dom";

const initialState = {
  otp: "",
  otpError: ""
};
 
 

class Verification extends Component {
  constructor(props) {
    super(props);
    // this.routeChangeHome = this.routeChangeHome.bind(this);
    this.state = { initialState, otpArray: "" };
    this.onSubmit = this.onSubmit.bind(this);
    this.onChange = this.onChange.bind(this);
  }

  componentDidMount() {
    const userid = localStorage.getItem("userid");

    axios
      .get(`http://localhost:6002/api/otp/gettingotp/${userid}`)
      .then(res => {
        console.log(res.data);
        this.setState({
          otpArray: res.data
        });
      })
      .catch(err => {
        console.log(err.response.data);
      });
  }

  onChange(e) {
    this.setState({ [e.target.name]: [e.target.value] });
  }

  validate = () => {
    let otpError = "";

    if (!this.state.otp) {
      otpError = "OTP Cannot be blank";
    }

    if (otpError) {
      this.setState({
        otpError
      });
      return false;
    }

    return true;
  };

  onSubmit(e) {
    e.preventDefault();

    console.log(this.state.otpArray);

    var valueObject = {
      otp: this.state.otp
    };
    // console.log(valueObject);
    const isValid = this.validate();
    if (isValid) {
      console.log(valueObject);

      axios
        .get(
          `http://localhost:6002/api/otp/checkingotp/${
            this.state.otpArray.userid
          }/${this.state.otp}`
        )
        .then(res => {
          console.log(res.data);
          if (res.data.status === 1) {
            alert("Verification Success");
            axios
              .delete(
                `http://localhost:6002/api/otp/otpdeletion/${
                  this.state.otpArray.userid
                }`
              )
              .then(response => {
                console.log(response.data);

                this.props.history.push("/home");
              })
              .catch(err => console.log(err));
          } else if (res.data.status === 0) {
            alert("Wrong OTP!");
          }
        })
        .catch(err => {
          alert(err.response.data);
        });
      this.setState(initialState);
    }
  }

  // routeChangeHome() {
  //   let path = "/home";
  //   this.props.history.push(path);
  // }
  routeChangeLogin() {}

  render() {
    return (
      <div style={{ backgroundColor: "brown" }}>
   <br />
       
        <br /><br />
        <br /><br />  
        <div className="row justify-content-lg-center">
          <div className="col-lg-5">
            <div className="card">
              <div className="card-body">
                <center>
                  {/* <img src={images} width="140px" height="100px" /> */}
                </center>
                <h3 align="center">OTP Verification</h3>
                <br />
                <form align="center" onSubmit={this.onSubmit}>
                  <div className="row justify-content-lg-center">
                    <div className="col-lg-8">
                      <div className="form-group">
                        <input
                          type="text"
                          className="form-control text-center"
                          placeholder="Enter OTP"
                          value={this.state.otp}
                          name="otp"
                          onChange={this.onChange}
                        />
                      </div>
                    </div>
                  </div>
                  {this.state.otpError ? (
                    <div className="alert alert-danger" role="alert">
                      {this.state.otpError}
                    </div>
                  ) : null}
                  <br />
                  <input
                    type="submit"
                    value="Sign in"
                    // onClick={e => this.routeChangeLogin()}
                    className="btn btn-primary"
                  />
                </form>
              </div>
            </div>
          </div>
        </div>
        <br />
        <br /><br />
        <br /><br />
        <br /><br />
        <br /><br />
        <br /><br />
        <br /><br />
        <br /><br />
        <br /><br />
        <br /><br />
        
        <br />
      </div>
    );
  }
}

export default Verification;
