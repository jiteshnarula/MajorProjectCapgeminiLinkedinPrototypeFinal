import React, { Component } from "react";
import axios from "axios";
import { Link } from "react-router-dom";

const initialState = {
  name: "",
  email: "",
  password: "",
  phonenumber: "",
  status: "",
  userid: "",
  // userimage: "",
  nameError: "",
  emailError: "",
  passwordError: "",
  phonenumberError: ""
  // userimageError: ""
};

class Register extends Component {
  constructor(props) {
    super(props);
    this.routeChangeHome = this.routeChangeHome.bind(this);
    this.state = initialState;
    this.onSubmit = this.onSubmit.bind(this);
    this.onChange = this.onChange.bind(this);
  }

  onChange(e) {
    this.setState({ [e.target.name]: [e.target.value] });
  }

  validate = () => {
    let nameError = "";
    let emailError = "";
    let passwordError = "";
    let phonenumberError = "";
    // let userimageError = "";

    var re = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
    console.log(re.test(String(this.state.email).toLowerCase()));

    if (!re.test(String(this.state.email).toLowerCase())) {
      emailError = "Invalid Email";
    }
    var rp = /^[\+]?[(]?[0-9]{3}[)]?[-\s\.]?[0-9]{3}[-\s\.]?[0-9]{4,6}$/im;
    console.log(rp.test(String(this.state.phonenumber)));
    if (!rp.test(String(this.state.phonenumber))) {
      phonenumberError = "Invalid PhoneNumber";
    }

    if (!this.state.name) {
      nameError = "Name Cannot be blank";
    }

    if (!this.state.password) {
      passwordError = "Password Cannot be blank";
    }

    // if (!this.state.userimage) {
    //   userimageError = "Userimage cannot be blank";
    // }

    if (
      emailError ||
      nameError ||
      phonenumberError ||
      // userimageError ||
      passwordError
    ) {
      this.setState({
        emailError,
        nameError,
        phonenumberError,
        // userimageError,
        passwordError
      });
      return false;
    }

    return true;
  };

  onSubmit(e) {
    e.preventDefault();

    // let fd = new FormData();
    // console.log(this.state.userimage);
    // fd.append("userimage", this.state.userimage);
    // console.log(fd);
    // const config = { headers: { "Content-Type": "multipart/form-data" } };

    var valueObject = {
      name: this.state.name,
      email: this.state.email,
      password: this.state.password,
      phonenumber: this.state.phonenumber
      // userimage: fd
    };

    const isValid = this.validate();
    if (isValid) {
      console.log(valueObject);
      axios
        .post("http://localhost:6002/api/users/register", valueObject)
        .then(res => {
          console.log(res.data);

          // this.setState(initialState);
          this.setState({
            status: res.data.status,
            userid: res.data.user._id
          });

          // alert(this.state.status + "," + this.state.userid);
          alert("Account successfully created");

          if (this.state.status) {
            // alert("entered");
            var val = Math.floor(1000 + Math.random() * 9000);

            valueObject = {
              verificationotp: val,
              email: this.state.email
            };

            axios
              .post(
                `http://localhost:6002/api/otp/verification/${
                  this.state.userid
                }`,
                valueObject
              )
              .then(res => {
                console.log(res.data);
                localStorage.setItem("userid", this.state.userid);
                localStorage.setItem("email", this.state.emailFonsubmi);
                this.props.history.push("/verification");
              })
              .catch(err => console.log(err));
          }
        })
        .catch(err => {
          console.log(err.response.data);
          if (err.response.data.error === 0) {
            alert(err.response.data.email);
          } else {
            alert("Not able to connect to the server");
          }
        });
      console.log(this.state.status);
    }
  }

  routeChangeHome() {
    let path = "/home";
    this.props.history.push(path);
  }
  routeChangeLogin() {}

  render() {
    return (
      <div style={{ backgroundColor: "brown" }}>
        <br />
        <br />
        <div className="row justify-content-lg-center">
          <div className="col-lg-5">
            <div className="card">
              <div className="card-body">
                <center>
                  {/* <img src={images} width="140px" height="100px" /> */}
                </center>
                <h3 align="center">Register Here</h3>
                <br />
                <form align="center" onSubmit={this.onSubmit}>
                  <div className="row justify-content-lg-center">
                    <div className="col-lg-8">
                      <div className="form-group">
                        <input
                          type="text"
                          className="form-control text-center"
                          placeholder="Enter Name"
                          value={this.state.name}
                          name="name"
                          onChange={this.onChange}
                        />
                      </div>
                    </div>
                  </div>
                  {this.state.nameError ? (
                    <div className="alert alert-danger" role="alert">
                      {this.state.nameError}
                    </div>
                  ) : null}
                  <div className=" row justify-content-lg-center">
                    <div className="col-lg-8">
                      <div className="form-group">
                        <input
                          type="text"
                          className="form-control text-center"
                          placeholder="Enter Email"
                          name="email"
                          value={this.state.email}
                          onChange={this.onChange}
                        />
                      </div>
                    </div>
                  </div>
                  {this.state.emailError ? (
                    <div className="alert alert-danger" role="alert">
                      {this.state.emailError}
                    </div>
                  ) : null}
                  <div className="row justify-content-lg-center">
                    <div className="col-lg-8">
                      <div className="form-group">
                        <input
                          type="text"
                          className="form-control text-center"
                          name="phonenumber"
                          placeholder="Enter Phone Number"
                          value={this.state.phonenumber}
                          onChange={this.onChange}
                        />
                      </div>
                    </div>
                  </div>
                  {this.state.phonenumberError ? (
                    <div className="alert alert-danger" role="alert">
                      {this.state.phonenumberError}
                    </div>
                  ) : null}
                  <div className="row justify-content-lg-center">
                    <div className="col-lg-8">
                      <div className="form-group">
                        <input
                          type="password"
                          className="form-control text-center"
                          name="password"
                          value={this.state.password}
                          placeholder="Enter Password"
                          onChange={this.onChange}
                        />
                      </div>
                    </div>
                  </div>
                  {this.state.passwordError ? (
                    <div className="alert alert-danger">
                      {this.state.passwordError}
                    </div>
                  ) : null}
                  {/* <div align="center">
                     <input
                      type="file"
                      className=" text-center"
                      name="userimage"
                      value={this.state.userimage}
                      onChange={this.onChange}
                    />
                  </div>
                  {this.state.userimageError ? (
                    <div className="alert alert-danger">
                      {this.state.userimageError}
                    </div>
                  ) : null} */}
                  <br />
                  <input
                    type="submit"
                    value="Sign in"
                    onClick={e => this.routeChangeLogin()}
                    className="btn btn-primary"
                  />
                  &nbsp;
                  <Link to="/" className="btn btn-success">
                    Go Back to Home
                  </Link>
                  <h6>
                    Already a user?&nbsp;
                    <Link className="btn btn-link" to="/login">
                      {" "}
                      Click here
                    </Link>
                  </h6>
                </form>
              </div>
            </div>
          </div>
        </div>
        <br />
        <br />
      </div>
    );
  }
}

export default Register;
